﻿class Sem10{ 
    static void Main(){ 
        int[] Numeros = new int[8];
        int suma = 0;

        for(int i = 0; i < 8; i++){ 
            Console.WriteLine($"Ingrese el número {i+1}:");
            Numeros[i] = int.Parse(Console.ReadLine());
            suma += Numeros[i];
        }

        Console.WriteLine("\nLos números ingresados son: ");
        foreach(int num in Numeros) Console.WriteLine(num + "");
        Console.WriteLine();
        
        Console.WriteLine($"La suma es: {suma}");

        double promedio = suma/8;
        Console.WriteLine($"El promedio es: {promedio}");   
    }
}