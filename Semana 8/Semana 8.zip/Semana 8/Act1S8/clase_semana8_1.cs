﻿class act1_sem8
{
    public static void Main()
    {
        int numPos = 0;

        while(true)
        {
            Console.WriteLine("Ingrese un número entero: ");
            
            
            if(int.TryParse(Console.ReadLine(), out numPos) && numPos > 0)
            {
                int resFac = CalcularFactorial(numPos);
                Console.WriteLine($"El factorial de {numPos} es: {resFac}");
                break;
            } 
            else
            {
                Console.WriteLine("Entrada inválida. Inténtalo de nuevo.");
            } 
        }
    }

    public static int CalcularFactorial(int numero)
    {
        if (numero == 0)
        {
            return 1;
        }
        else
        {
            int factorial = 1;
            for (int i = 1; i <= numero; i++)
            {
                factorial *= i;
            }
        return factorial;
        }
    }
}