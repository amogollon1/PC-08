﻿namespace PrimerParcialAlejandroMogollón{
    class Parcial1
    {
        static void Main(string []args)
        {
            int n1 = 0, n2 = 0, n3 = 0;

            Console.WriteLine("Ingrese el primer número: ");
            n1 = Convert.ToInt32(Console.ReadLine());

            if (n1 % 2 == 0)
            {
                Console.WriteLine("Número " + n1 + " es par");
            }
            else 
            {
                Console.WriteLine("Número " + n1 + " es impar");
            }

            Console.WriteLine("Ingrese el segundo número: ");
            n1 = Convert.ToInt32(Console.ReadLine());

            if (n2 % 2 == 0)
            {
                Console.WriteLine("Número " + n2 + " es par");
            }
            else 
            {
                Console.WriteLine("Número " + n2 + " es impar");
            }

            Console.WriteLine("Ingrese el tercer número: ");
            n1 = Convert.ToInt32(Console.ReadLine());

            if (n1 % 2 == 0)
            {
                Console.WriteLine("Número " + n3 + " es par");
            }
            else 
            {
                Console.WriteLine("Número " + n3 + " es impar");
            }

            Console.ReadKey();
        }
    }
}
