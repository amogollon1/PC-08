﻿class Program{
    public static void Main(String[]args){
        int n = 0, r = 0;

        while(true){
            Console.WriteLine("Ingrese un número entero:");

            if(int.TryParse(Console.ReadLine(), out n) && n > 0 && n <= 999999){
                for(int i = 1; i <= n; i++){
                    if(n % i == 0){
                        r++;
                    }
                    else{

                    }
                }
                if(r > 2){
                    Console.WriteLine("El número ingresado no es primo.");
                }
                else{
                    Console.WriteLine("El número sí es primo.");
                }
                break;
            }
            else{
                Console.WriteLine("Ingrese un valor válido.\n");
            }
        }
    }
}